# Change log of the R package 'via'

# via 0.1.0. - 2023-03-09
### Added 
- Implementable classes: XArray, SfArray, RasterArray

### Fixed
- Class organization


* * *


# via 0.0.1 - 2022-08-13

### Initialize 
Material moved from the chronosphere package. 
